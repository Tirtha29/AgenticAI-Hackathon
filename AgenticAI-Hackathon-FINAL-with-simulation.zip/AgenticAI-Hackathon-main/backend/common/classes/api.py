from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, FiniteFloat


class TelemetryIn(BaseModel):
    timestamp: datetime | None = None
    device_id: str = Field(min_length=1, max_length=128)
    metrics: dict[str, FiniteFloat] = Field(min_length=1)
    units: dict[str, str] = Field(default_factory=dict)


class HumanInformationIn(BaseModel):
    answers: dict[str, bool | str | FiniteFloat] = Field(min_length=1)


class ReviewIn(BaseModel):
    reviewer: str = Field(min_length=1, max_length=120)
    decision: str = Field(pattern="^(confirmed|rejected)$")
    feedback: str | None = Field(default=None, max_length=2000)


class SimulationIn(BaseModel):
    """What-if event scenario. Omitted values fall back to the event-type preset."""

    event_name: str | None = Field(default=None, max_length=80)
    event_type: Literal["festival", "sports", "livestream", "exam", "outage"] = "festival"
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    attendance: int | None = Field(default=None, ge=1, le=500_000)
    radius_km: float | None = Field(default=None, ge=0.05, le=10)
    duration_min: int | None = Field(default=None, ge=15, le=720)
    capacity_boost_pct: float = Field(default=0, ge=0, le=300)
    traffic_shaping_pct: float = Field(default=0, ge=0, le=80)
    use_live_health: bool = True
