"""Visuals for the Event Simulation page.

`radar_html(result)` returns one self-contained HTML document (no network
access, no external libraries) that animates the simulation result on a canvas:
epicentre ripples, device health per time frame, animated spill-over arcs, a
live "right now" ranking and a draggable timeline.  It runs entirely in the
browser, so playing / scrubbing never triggers a Streamlit rerun.

`PAGE_CSS` styles the surrounding Streamlit widgets (KPI strip, recommendation
cards, scenario banner).
"""
from __future__ import annotations

import json
from typing import Any

PAGE_CSS = """
.sim-hero{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;gap:18px;padding:16px 22px;margin:0 0 14px;border-radius:22px;color:#e9ecff;
background:radial-gradient(ellipse at 90% 0%,rgba(244,114,182,.32) 0,transparent 45%),radial-gradient(ellipse at 0% 100%,rgba(99,102,241,.38) 0,transparent 50%),linear-gradient(120deg,#171a3a,#241b4d 55%,#3a1f4f);
box-shadow:0 14px 34px rgba(36,27,77,.28);}
.sim-hero:after{content:"";position:absolute;right:-40px;top:-40px;width:200px;height:200px;border-radius:50%;border:1px solid rgba(255,255,255,.14);box-shadow:0 0 0 28px rgba(255,255,255,.04),0 0 0 60px rgba(255,255,255,.025);animation:simpulse 3.2s ease-out infinite;pointer-events:none;}
@keyframes simpulse{0%{transform:scale(.85);opacity:.9}100%{transform:scale(1.35);opacity:0}}
.sim-hero h3{margin:0;color:#fff;font-size:1.15rem;letter-spacing:-.01em;}
.sim-hero p{margin:3px 0 0;color:#c4c9ee;font-size:.86rem;max-width:720px;}
.sim-tag{display:inline-flex;align-items:center;gap:8px;padding:7px 14px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);font-size:.8rem;font-weight:600;white-space:nowrap;position:relative;z-index:1;}
.sim-tag i{width:8px;height:8px;border-radius:50%;background:#fb7185;box-shadow:0 0 0 4px rgba(251,113,133,.25);}
.sim-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:2px 0 14px;}
.sim-kpi{padding:13px 15px;border-radius:16px;border:1px solid var(--line);background:linear-gradient(150deg,#fff,#f6f4ff);box-shadow:0 5px 16px rgba(50,62,100,.05);position:relative;overflow:hidden;}
.sim-kpi:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--c,#6253b7);}
.sim-kpi .k{font-size:.74rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--muted);}
.sim-kpi .v{font-size:1.65rem;font-weight:800;letter-spacing:-.03em;color:var(--ink);line-height:1.15;margin-top:2px;}
.sim-kpi .n{font-size:.76rem;color:var(--muted);margin-top:2px;}
.rec-card{display:flex;gap:14px;padding:14px 16px;margin:0 0 10px;border-radius:16px;border:1px solid var(--line);background:#fff;box-shadow:0 4px 14px rgba(50,62,100,.045);}
.rec-card .bar{width:5px;border-radius:99px;flex-shrink:0;}
.rec-card.p-critical .bar{background:#ef5c62}.rec-card.p-warning .bar{background:#f3b61f}.rec-card.p-info .bar{background:#20b981}
.rec-title{font-weight:750;color:var(--ink);font-size:.97rem;display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
.rec-eta{font-size:.72rem;font-weight:700;padding:2px 9px;border-radius:99px;background:#eceaff;color:#4b3f9e;}
.rec-text{color:#34405c;font-size:.88rem;margin-top:4px;line-height:1.4;}
.rec-areas{margin-top:8px;display:flex;flex-wrap:wrap;gap:6px;}
.rec-areas span{font-size:.74rem;padding:3px 10px;border-radius:99px;background:#f3f1ff;border:1px solid #e3def8;color:#46526f;}
.role-chip{display:inline-block;padding:2px 9px;border-radius:99px;font-size:.72rem;font-weight:700;}
"""

_TEMPLATE = r"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;background:transparent;font-family:Inter,'Segoe UI',system-ui,sans-serif;color:#e8ebff;overflow:hidden}
.shell{height:100%;display:flex;flex-direction:column;border-radius:22px;overflow:hidden;border:1px solid #2c2f5c;
background:radial-gradient(ellipse at 20% 0%,#23245a 0,transparent 55%),radial-gradient(ellipse at 100% 100%,#3a1c52 0,transparent 50%),#0f1230;box-shadow:0 18px 40px rgba(15,18,48,.35)}
.top{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px 8px}
.ttl{display:flex;align-items:center;gap:10px;font-weight:700;font-size:.95rem;letter-spacing:-.01em}
.live{width:9px;height:9px;border-radius:50%;background:#fb7185;box-shadow:0 0 0 0 rgba(251,113,133,.7);animation:blink 1.6s infinite}
@keyframes blink{70%{box-shadow:0 0 0 9px rgba(251,113,133,0)}100%{box-shadow:0 0 0 0 rgba(251,113,133,0)}}
.clock{font-variant-numeric:tabular-nums;font-weight:800;font-size:1.05rem;color:#fff}
.phase{font-size:.7rem;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:3px 10px;border-radius:99px;background:rgba(255,255,255,.1);color:#c9ceff;margin-left:8px}
.chips{display:flex;gap:8px;flex-wrap:wrap}
.chip{display:flex;align-items:center;gap:7px;padding:5px 11px;border-radius:99px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);font-size:.76rem;font-weight:600;color:#d7dbff;white-space:nowrap}
.chip b{font-size:.92rem;color:#fff;font-variant-numeric:tabular-nums}
.dot{width:9px;height:9px;border-radius:50%}
.main{flex:1;min-height:0;display:flex;gap:12px;padding:0 14px}
.stage{position:relative;flex:1;min-width:0;border-radius:16px;overflow:hidden;border:1px solid rgba(255,255,255,.08);
background:radial-gradient(circle at 50% 45%,rgba(98,83,183,.28) 0,rgba(15,18,48,.2) 65%),#0c0f28}
canvas{display:block;width:100%;height:100%}
.tip{position:absolute;pointer-events:none;z-index:5;min-width:190px;max-width:260px;padding:10px 12px;border-radius:12px;background:rgba(12,15,40,.96);border:1px solid rgba(255,255,255,.16);box-shadow:0 10px 26px rgba(0,0,0,.45);font-size:.74rem;line-height:1.4;display:none}
.tip b{display:block;font-size:.84rem;margin-bottom:2px;color:#fff}
.tip .m{color:#aab0e6}
.legend{position:absolute;left:12px;bottom:10px;display:flex;gap:12px;flex-wrap:wrap;font-size:.68rem;color:#aab0e6;background:rgba(12,15,40,.7);padding:6px 10px;border-radius:10px;border:1px solid rgba(255,255,255,.08)}
.legend span{display:flex;align-items:center;gap:5px}
.side{width:270px;flex-shrink:0;display:flex;flex-direction:column;gap:8px;min-height:0}
.side h4{font-size:.7rem;letter-spacing:.08em;text-transform:uppercase;color:#9aa1dd;margin:2px 2px 0}
.rows{display:flex;flex-direction:column;gap:6px;overflow:hidden}
.row{padding:7px 9px;border-radius:11px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.07);transition:background .2s}
.row .h{display:flex;justify-content:space-between;align-items:center;gap:6px;font-size:.76rem;font-weight:650}
.row .h span:first-child{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.row .s{font-size:.66rem;color:#9aa1dd;margin-top:1px}
.bar{height:5px;border-radius:99px;background:rgba(255,255,255,.1);margin-top:5px;overflow:hidden}
.bar i{display:block;height:100%;border-radius:99px;transition:width .25s,background .25s}
.role{font-size:.62rem;font-weight:800;letter-spacing:.04em;text-transform:uppercase;padding:1px 7px;border-radius:99px;flex-shrink:0}
.bottom{padding:8px 14px 12px}
.ctl{display:flex;align-items:center;gap:10px;margin-bottom:6px}
button,select{font:inherit;color:#fff;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);border-radius:10px;padding:5px 12px;cursor:pointer;font-size:.8rem;font-weight:650}
button:hover{background:rgba(255,255,255,.18)}
button.play{background:linear-gradient(135deg,#7c6bdc,#5a4aa8);border:0;min-width:84px}
select option{color:#111}
.tlwrap{position:relative;flex:1;height:64px;border-radius:12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);overflow:hidden;cursor:ew-resize}
.hint{font-size:.64rem;color:#8f96d6;max-width:150px;line-height:1.3}
@media(max-width:820px){.side{display:none}.chips{display:none}}
</style></head><body>
<div class="shell">
  <div class="top">
    <div class="ttl"><span class="live"></span><span id="name"></span><span class="phase" id="phase"></span></div>
    <div class="chips">
      <div class="chip"><span class="dot" style="background:#f87171"></span>Critical <b id="nC">0</b></div>
      <div class="chip"><span class="dot" style="background:#fbbf24"></span>Warning <b id="nW">0</b></div>
      <div class="chip"><span class="dot" style="background:#34d399"></span>Healthy <b id="nH">0</b></div>
      <div class="chip">Load <b id="load">0%</b></div>
    </div>
    <div class="clock" id="clock">T+0 min</div>
  </div>
  <div class="main">
    <div class="stage" id="stage"><canvas id="map"></canvas><div class="tip" id="tip"></div>
      <div class="legend"><span><i class="dot" style="background:#34d399"></i>Healthy</span><span><i class="dot" style="background:#fbbf24"></i>Warning &ge;75%</span><span><i class="dot" style="background:#f87171"></i>Overloaded &ge;100%</span><span><svg width="22" height="8"><line x1="1" y1="4" x2="21" y2="4" stroke="#fb923c" stroke-width="2.5" stroke-dasharray="4 3"/></svg>Spill-over of clients</span><span>&#9679; AP &nbsp;&#9632; switch &nbsp;&#9670; router &nbsp;&#9650; perimeter</span></div>
    </div>
    <div class="side"><h4>Most stressed right now</h4><div class="rows" id="rows"></div></div>
  </div>
  <div class="bottom">
    <div class="ctl">
      <button id="rst" title="Restart">&#9198;</button>
      <button class="play" id="play">&#10074;&#10074; Pause</button>
      <select id="spd"><option value="0.5">0.5&times;</option><option value="1" selected>1&times;</option><option value="2">2&times;</option><option value="4">4&times;</option></select>
      <div class="tlwrap" id="tlw"><canvas id="tl"></canvas></div>
      <span class="hint">drag to scrub &middot; red/amber = devices in trouble &middot; violet = crowd &middot; line = load</span>
    </div>
  </div>
</div>
<script>
const D = __DATA__;
const COL = ['#34d399','#fbbf24','#f87171'];
const N = D.minutes.length;
const byId = {}; D.devices.forEach((d,i) => {d.idx=i; byId[d.id] = d;});
const cv = document.getElementById('map'), ctx = cv.getContext('2d');
const tl = document.getElementById('tl'), tctx = tl.getContext('2d');
const tip = document.getElementById('tip');
let W=0,H=0,TW=0,TH=0,proj=null,fp=0,playing=true,speed=1,last=performance.now(),hover=null,lastInt=-1;
document.getElementById('name').textContent = D.name;

function sizeCanvas(c, x){const r=c.parentElement.getBoundingClientRect();const k=window.devicePixelRatio||1;c.width=r.width*k;c.height=r.height*k;x.setTransform(k,0,0,k,0,0);return [r.width,r.height];}
function buildProj(){
  const lat0 = D.devices.reduce((a,d)=>a+d.lat,0)/D.devices.length, kx = Math.cos(lat0*Math.PI/180);
  const dLat = D.radius_km/111.32, dLon = dLat/kx;
  let lats=[D.epi.lat-dLat*0.9, D.epi.lat+dLat*0.9], lons=[D.epi.lon-dLon*0.9, D.epi.lon+dLon*0.9];
  D.devices.forEach(d=>{lats.push(d.lat);lons.push(d.lon)});
  const minLat=Math.min(...lats),maxLat=Math.max(...lats),minLon=Math.min(...lons),maxLon=Math.max(...lons);
  const padX=60,padY=46, spanX=Math.max((maxLon-minLon)*kx,1e-6), spanY=Math.max(maxLat-minLat,1e-6);
  const s=Math.min((W-2*padX)/spanX,(H-2*padY)/spanY);
  const mx=(minLon+maxLon)/2,my=(minLat+maxLat)/2;
  proj={k:s/111.32, p:(lon,lat)=>[W/2+(lon-mx)*kx*s, H/2-(lat-my)*s]};
  D.devices.forEach(d=>{[d.x,d.y]=proj.p(d.lon,d.lat)});
  [D.epi.x,D.epi.y]=proj.p(D.epi.lon,D.epi.lat);
}
function resize(){[W,H]=sizeCanvas(cv,ctx);[TW,TH]=sizeCanvas(tl,tctx);buildProj();drawTL();}
function util(id,f){const u=D.util[id];const i0=Math.floor(f),i1=Math.min(i0+1,N-1);return u[i0]+(u[i1]-u[i0])*(f-i0);}
function sev(u){return u>=1?2:(u>=0.75?1:0);}
function flowAt(fl,f){const i0=Math.floor(f),i1=Math.min(i0+1,N-1);return fl.series[i0]+(fl.series[i1]-fl.series[i0])*(f-i0);}
function presenceAt(f){const i0=Math.floor(f),i1=Math.min(i0+1,N-1);return D.presence[i0]+(D.presence[i1]-D.presence[i0])*(f-i0);}

function shape(d,r){
  ctx.beginPath();
  if(d.type==='access point'){ctx.arc(d.x,d.y,r,0,7);}
  else if(d.type==='switch'||d.type==='network device'){const a=r*0.95;ctx.roundRect(d.x-a,d.y-a,a*2,a*2,3);}
  else if(d.type==='router'){ctx.moveTo(d.x,d.y-r*1.25);ctx.lineTo(d.x+r*1.25,d.y);ctx.lineTo(d.x,d.y+r*1.25);ctx.lineTo(d.x-r*1.25,d.y);ctx.closePath();}
  else {ctx.moveTo(d.x,d.y-r*1.2);ctx.lineTo(d.x+r*1.1,d.y+r*0.9);ctx.lineTo(d.x-r*1.1,d.y+r*0.9);ctx.closePath();}
}

function draw(now){
  ctx.clearRect(0,0,W,H);
  // grid
  ctx.strokeStyle='rgba(160,170,255,.06)';ctx.lineWidth=1;
  for(let x=0;x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
  for(let y=0;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke();}
  const R=D.radius_km*proj.k, pres=Math.min(1.2,presenceAt(fp));
  // crowd zone
  const g=ctx.createRadialGradient(D.epi.x,D.epi.y,0,D.epi.x,D.epi.y,R*(1+0.15*pres));
  g.addColorStop(0,'rgba(251,113,133,'+(0.34*pres)+')');g.addColorStop(1,'rgba(251,113,133,0)');
  ctx.fillStyle=g;ctx.beginPath();ctx.arc(D.epi.x,D.epi.y,R*1.15,0,7);ctx.fill();
  ctx.setLineDash([5,6]);ctx.strokeStyle='rgba(251,113,133,.55)';ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(D.epi.x,D.epi.y,R,0,7);ctx.stroke();ctx.setLineDash([]);
  // ripples
  for(let k=0;k<3;k++){const ph=((now/2800)+k/3)%1;ctx.strokeStyle='rgba(251,113,133,'+((1-ph)*0.55*Math.min(1,pres))+')';ctx.lineWidth=2;ctx.beginPath();ctx.arc(D.epi.x,D.epi.y,ph*R*1.9+6,0,7);ctx.stroke();}
  // links
  D.links.forEach(l=>{const a=byId[l[0]],b=byId[l[1]];if(!a||!b)return;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);
    const worst=Math.max(sev(util(a.id,fp)),sev(util(b.id,fp)));
    ctx.strokeStyle=l[2]?'rgba(190,196,255,.22)':(worst===2?'rgba(248,113,113,.38)':'rgba(190,196,255,.28)');ctx.lineWidth=l[2]?1:1.4;ctx.setLineDash(l[2]?[3,5]:[]);ctx.stroke();ctx.setLineDash([]);});
  // spill flows
  const maxF=Math.max(1,...D.flows.map(f=>f.peak));
  D.flows.forEach(fl=>{const a=byId[fl.from],b=byId[fl.to];const v=flowAt(fl,fp);if(!a||!b||v<0.5)return;
    const mx=(a.x+b.x)/2,my=(a.y+b.y)/2,dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy)||1,bend=Math.min(60,len*0.35);
    const cx=mx-dy/len*bend,cy=my+dx/len*bend;
    ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.quadraticCurveTo(cx,cy,b.x,b.y);
    ctx.strokeStyle='rgba(251,146,60,'+(0.45+0.5*v/maxF)+')';ctx.lineWidth=1.2+4*v/maxF;ctx.setLineDash([7,9]);ctx.lineDashOffset=-now/28;ctx.shadowColor='#fb923c';ctx.shadowBlur=8;ctx.stroke();
    ctx.setLineDash([]);ctx.shadowBlur=0;
    const t=((now/1100)+(fl.from.length%5)/5)%1,qx=(1-t)*(1-t)*a.x+2*(1-t)*t*cx+t*t*b.x,qy=(1-t)*(1-t)*a.y+2*(1-t)*t*cy+t*t*b.y;
    ctx.fillStyle='#ffd8b0';ctx.beginPath();ctx.arc(qx,qy,2.6,0,7);ctx.fill();});
  // nodes
  D.devices.forEach(d=>{
    const u=util(d.id,fp),s=d.role==='offline'?2:sev(u),c=d.role==='offline'?'#94a3b8':COL[s],r=7+(d.type==='router'?1:0);
    if(s>=1){const pulse=0.5+0.5*Math.sin(now/(s===2?240:420)+d.x);ctx.fillStyle=(s===2?'rgba(248,113,113,':'rgba(251,191,36,')+(0.12+0.2*pulse)+')';ctx.beginPath();ctx.arc(d.x,d.y,r+6+8*pulse,0,7);ctx.fill();}
    shape(d,r);ctx.fillStyle=c;ctx.fill();ctx.lineWidth=2;ctx.strokeStyle=hover===d?'#fff':'rgba(12,15,40,.9)';ctx.stroke();
    if(d.role==='offline'){ctx.strokeStyle='#f87171';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(d.x-5,d.y-5);ctx.lineTo(d.x+5,d.y+5);ctx.moveTo(d.x+5,d.y-5);ctx.lineTo(d.x-5,d.y+5);ctx.stroke();}
    if(s>=1||hover===d){const tag={'access point':'AP','switch':'SW','router':'RTR','firewall':'FW','gateway':'GW'}[d.type]||'';const t=d.area+(tag?' \u00b7 '+tag:'');ctx.font='600 10.5px Inter,system-ui,sans-serif';ctx.textAlign='center';const w=ctx.measureText(t).width+10,ly=d.y-r-(d.type==='access point'?18:12)-((d.idx%2)*0);ctx.fillStyle='rgba(12,15,40,.72)';ctx.beginPath();ctx.roundRect(d.x-w/2,ly-11,w,15,6);ctx.fill();ctx.fillStyle='rgba(235,238,255,.95)';ctx.fillText(t,d.x,ly);}
  });
  // epicentre
  ctx.fillStyle='#fb7185';ctx.shadowColor='#fb7185';ctx.shadowBlur=16;ctx.beginPath();ctx.arc(D.epi.x,D.epi.y,5.5,0,7);ctx.fill();ctx.shadowBlur=0;
  ctx.strokeStyle='#fff';ctx.lineWidth=1.6;ctx.stroke();
  ctx.font='700 11px Inter,system-ui,sans-serif';ctx.textAlign='center';ctx.fillStyle='#ffd1da';ctx.fillText('EVENT · '+D.epi.label,D.epi.x,Math.max(14,D.epi.y-R-10));
}

function drawTL(){
  tctx.clearRect(0,0,TW,TH);const bw=TW/N;
  const maxC=Math.max(1,D.n_total);
  for(let i=0;i<N;i++){
    const x=i*bw,p=Math.min(1,D.presence[i]);
    tctx.fillStyle='rgba(124,107,220,.35)';tctx.fillRect(x,TH-p*TH*0.55,bw+0.5,p*TH*0.55);
    const c=D.tl_c[i]/maxC*(TH-6),w=D.tl_w[i]/maxC*(TH-6);
    tctx.fillStyle='rgba(248,113,113,.9)';tctx.fillRect(x,TH-c,bw+0.5,c);
    tctx.fillStyle='rgba(251,191,36,.85)';tctx.fillRect(x,TH-c-w,bw+0.5,w);
  }
  tctx.strokeStyle='#c4b5fd';tctx.lineWidth=1.5;tctx.beginPath();
  D.load.forEach((v,i)=>{const y=TH-Math.min(1.3,v/100)/1.3*(TH-6)-2,x=(i+0.5)*bw;i?tctx.lineTo(x,y):tctx.moveTo(x,y);});tctx.stroke();
  const px=(fp+0.5)*bw;tctx.strokeStyle='#fff';tctx.lineWidth=2;tctx.beginPath();tctx.moveTo(px,0);tctx.lineTo(px,TH);tctx.stroke();
  tctx.fillStyle='#fff';tctx.beginPath();tctx.arc(px,5,4,0,7);tctx.fill();
}

const ROLE={direct:['#f87171','Epicentre'],spillover:['#fb923c','Spill-over'],upstream:['#c084fc','Uplink'],collateral:['#60a5fa','Bystander'],offline:['#94a3b8','Offline'],unaffected:['#34d399','OK']};
function phaseName(m){const t=m/D.duration;if(t<D.ramp)return 'Arrival';if(t<=D.end)return 'Peak';if(t<=D.end+0.35)return 'Dispersal';return 'Wind-down';}
function updatePanel(){
  const i=Math.round(fp);if(i===lastInt)return;lastInt=i;
  const m=D.minutes[i];document.getElementById('clock').textContent='T+'+m+' min';document.getElementById('phase').textContent=phaseName(m);
  document.getElementById('nC').textContent=D.tl_c[i];document.getElementById('nW').textContent=D.tl_w[i];document.getElementById('nH').textContent=D.n_total-D.tl_c[i]-D.tl_w[i];
  document.getElementById('load').textContent=Math.round(D.load[i])+'%';
  const list=D.devices.map(d=>({d,u:D.util[d.id][i]})).sort((a,b)=>b.u-a.u).slice(0,Math.max(3,Math.floor((H-30)/58)));
  document.getElementById('rows').innerHTML=list.map(({d,u})=>{const s=d.role==='offline'?2:sev(u),c=d.role==='offline'?'#94a3b8':COL[s],r=ROLE[d.role]||ROLE.unaffected;
    return '<div class="row"><div class="h"><span>'+d.area+' <span style="color:#9aa1dd;font-weight:500">'+d.type+'</span></span><span class="role" style="background:'+r[0]+'26;color:'+r[0]+'">'+r[1]+'</span></div>'
    +'<div class="s">'+(d.role==='offline'?'offline':Math.round(u*100)+'% utilisation')+'</div><div class="bar"><i style="width:'+Math.min(100,u*100/1.5)+'%;background:'+c+'"></i></div></div>';}).join('');
}
function loop(now){
  const rc=cv.parentElement.getBoundingClientRect();if(Math.abs(rc.width-W)>1||Math.abs(rc.height-H)>1){resize();lastInt=-1;}
  const dt=(now-last)/1000;last=now;
  if(playing){fp+=dt*speed*2.2;if(fp>=N-1){fp=N-1;playing=false;setBtn();}}
  draw(now);updatePanel();drawTL();requestAnimationFrame(loop);
}
function setBtn(){document.getElementById('play').innerHTML=playing?'&#10074;&#10074; Pause':'&#9654; Play';}
document.getElementById('play').onclick=()=>{if(!playing&&fp>=N-1)fp=0;playing=!playing;setBtn();};
document.getElementById('rst').onclick=()=>{fp=0;playing=true;setBtn();};
document.getElementById('spd').onchange=e=>speed=parseFloat(e.target.value);
let drag=false;
function seek(e){const r=tl.getBoundingClientRect();const x=(e.touches?e.touches[0].clientX:e.clientX)-r.left;fp=Math.max(0,Math.min(N-1,x/r.width*N-0.5));playing=false;setBtn();}
tl.addEventListener('mousedown',e=>{drag=true;seek(e)});window.addEventListener('mousemove',e=>{if(drag)seek(e)});window.addEventListener('mouseup',()=>drag=false);
tl.addEventListener('touchstart',seek,{passive:true});tl.addEventListener('touchmove',seek,{passive:true});
cv.addEventListener('mousemove',e=>{const r=cv.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;
  hover=D.devices.find(d=>Math.hypot(d.x-x,d.y-y)<14)||null;
  if(!hover){tip.style.display='none';return;}
  const u=util(hover.id,fp),d=hover;
  tip.innerHTML='<b>'+d.name+'</b><div class="m">'+d.id+' · '+d.type+' · '+Math.round(d.dist*1000)+' m from event</div>'
   +'<div style="margin-top:5px">Now: <b style="display:inline;color:'+(d.role==='offline'?'#94a3b8':COL[sev(u)])+'">'+(d.role==='offline'?'offline':Math.round(u*100)+'%')+'</b> · peak '+Math.round(d.peak*100)+'%</div>'
   +'<div class="m">Role: '+(ROLE[d.role]||ROLE.unaffected)[1]+(d.t_over!=null?' · overload at T+'+d.t_over+' min':'')+'</div>'
   +'<div class="m">Latency '+d.lat_ms+' ms · loss '+d.loss+'%</div><div style="margin-top:5px;color:#dfe2ff">'+d.reason+'</div>';
  tip.style.display='block';tip.style.left=Math.min(x+16,W-270)+'px';tip.style.top=Math.max(6,Math.min(y+12,H-150))+'px';});
cv.addEventListener('mouseleave',()=>{hover=null;tip.style.display='none'});
window.addEventListener('resize',()=>{resize();lastInt=-1});
resize();setBtn();requestAnimationFrame(loop);
</script></body></html>"""


def radar_html(result: dict[str, Any]) -> str:
    scenario = result["scenario"]
    frames = result["frames"]
    timeline = result["timeline"]
    devices = [
        {
            "id": d["device_id"], "name": d["name"], "area": d["area"], "type": d["device_type"],
            "lat": d["latitude"], "lon": d["longitude"], "role": d["role"], "peak": d["peak_utilization"],
            "dist": d["distance_km"], "t_over": d["time_to_overload_min"], "lat_ms": d["peak_latency_ms"],
            "loss": d["peak_packet_loss_pct"], "reason": d["reasons"][0],
        }
        for d in result["devices"]
    ]
    inferred = {tuple(sorted(pair)) for pair in result["inferred_links"]}
    data = {
        "name": scenario["event_name"],
        "devices": devices,
        "links": [[a, b, 1 if (a, b) in inferred else 0] for a, b in result["links"]],
        "flows": [{"from": f["from"], "to": f["to"], "peak": f["peak_mbps"], "series": f["series"]} for f in result["spill_flows"]],
        "minutes": frames["minutes"],
        "util": frames["utilization"],
        "presence": [t["presence"] for t in timeline],
        "load": [t["network_load_pct"] for t in timeline],
        "tl_c": [t["critical"] for t in timeline],
        "tl_w": [t["warning"] for t in timeline],
        "n_total": len(devices),
        "epi": {"lat": scenario["latitude"], "lon": scenario["longitude"], "label": result["summary"]["epicentre_area"]},
        "radius_km": scenario["radius_km"],
        "duration": scenario["duration_min"],
        "ramp": scenario["ramp_up"],
        "end": scenario["plateau_end"],
    }
    payload = json.dumps(data, separators=(",", ":")).replace("</", "<\\/")
    return _TEMPLATE.replace("__DATA__", payload)
